// Toggle Mobile Menu
document.querySelector(".menu-toggle").addEventListener("click", () => {
    document.querySelector(".nav-links").classList.toggle("active");
});

// Smooth Scroll
document.querySelectorAll(".nav-links a").forEach(anchor => {
    anchor.addEventListener("click", function(event) {
        event.preventDefault();
        const targetId = this.getAttribute("href").substring(1);
        document.getElementById(targetId).scrollIntoView({ behavior: "smooth" });
    });
});

// Animate Skill Progress Bars
window.addEventListener("scroll", () => {
    document.querySelectorAll(".progress-bar").forEach(bar => {
        const width = bar.style.width;
        bar.style.width = "0"; // Reset width
        setTimeout(() => {
            bar.style.width = width; // Animate width
        }, 500);
    });
});

// Contact Form Validation
document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const name = this.name.value.trim();
    const email = this.email.value.trim();
    const message = this.message.value.trim();

    if (name === "" || email === "" || message === "") {
        alert("Please fill in all fields.");
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        alert("Please enter a valid email address.");
        return;
    }
    
    alert("Message sent successfully!");
    this.reset();
});
